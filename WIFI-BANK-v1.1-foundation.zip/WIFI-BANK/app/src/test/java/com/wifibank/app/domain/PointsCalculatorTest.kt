package com.wifibank.app.domain

import com.wifibank.app.domain.model.WalletState
import com.wifibank.app.domain.usecase.PointsCalculator
import org.junit.Assert.assertEquals
import org.junit.Test

class PointsCalculatorTest {
    private val calculator = PointsCalculator()

    @Test fun oneGbWifiEarnsOneHundredPoints() {
        val result = calculator.applyDelta(WalletState(), 1_000_000_000L, 0L)
        assertEquals(100L, result.wifiPoints)
        assertEquals(0L, result.mobilePoints)
    }

    @Test fun oneGbMobileEarnsFiftyPoints() {
        val result = calculator.applyDelta(WalletState(), 0L, 1_000_000_000L)
        assertEquals(50L, result.mobilePoints)
    }

    @Test fun fractionalUsageCarriesAcrossRefreshes() {
        val first = calculator.applyDelta(WalletState(), 500_000_000L, 0L)
        val second = calculator.applyDelta(first, 500_000_000L, 0L)
        assertEquals(100L, second.wifiPoints)
    }

    @Test fun zeroDeltaDoesNotCreatePoints() {
        val result = calculator.applyDelta(WalletState(wifiPoints = 25L), 0L, 0L)
        assertEquals(25L, result.wifiPoints)
    }

    @Test(expected = IllegalArgumentException::class)
    fun negativeDeltaIsRejected() {
        calculator.applyDelta(WalletState(), -1L, 0L)
    }
}
