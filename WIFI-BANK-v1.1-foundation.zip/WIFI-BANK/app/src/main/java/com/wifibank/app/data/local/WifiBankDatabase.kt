package com.wifibank.app.data.local

import androidx.room.Database
import androidx.room.RoomDatabase

@Database(entities = [WalletEntity::class], version = 1, exportSchema = true)
abstract class WifiBankDatabase : RoomDatabase() {
    abstract fun walletDao(): WalletDao
}
