package com.wifibank.app.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "wallet")
data class WalletEntity(
    @PrimaryKey val id: Int = 1,
    val wifiPoints: Long = 0L,
    val mobilePoints: Long = 0L,
    val wifiBytesAccounted: Long = 0L,
    val mobileBytesAccounted: Long = 0L,
    val lastWifiTotalBytes: Long = 0L,
    val lastMobileTotalBytes: Long = 0L,
    val baselineStartAt: Long = 0L,
    val isCollectionEnabled: Boolean = true
)
