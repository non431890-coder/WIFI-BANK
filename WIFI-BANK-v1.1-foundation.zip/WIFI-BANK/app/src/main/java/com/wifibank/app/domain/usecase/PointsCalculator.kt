package com.wifibank.app.domain.usecase

import com.wifibank.app.domain.model.WalletState

/**
 * Converts byte deltas into virtual points.
 * Defaults preserve the project specification: 100 points/GB Wi-Fi,
 * 50 points/GB mobile data. Fractions are carried forward as bytes.
 */
class PointsCalculator(
    private val wifiPointsPerGb: Long = 100L,
    private val mobilePointsPerGb: Long = 50L
) {
    init {
        require(wifiPointsPerGb >= 0L)
        require(mobilePointsPerGb >= 0L)
    }

    fun applyDelta(
        current: WalletState,
        wifiDeltaBytes: Long,
        mobileDeltaBytes: Long
    ): WalletState {
        require(wifiDeltaBytes >= 0L) { "Wi-Fi delta must not be negative" }
        require(mobileDeltaBytes >= 0L) { "Mobile delta must not be negative" }

        val wifiTotal = safeAdd(current.wifiBytesAccounted, wifiDeltaBytes)
        val mobileTotal = safeAdd(current.mobileBytesAccounted, mobileDeltaBytes)
        val wifiEarned = pointsFor(wifiTotal, wifiPointsPerGb) -
            pointsFor(current.wifiBytesAccounted, wifiPointsPerGb)
        val mobileEarned = pointsFor(mobileTotal, mobilePointsPerGb) -
            pointsFor(current.mobileBytesAccounted, mobilePointsPerGb)

        return current.copy(
            wifiPoints = safeAdd(current.wifiPoints, wifiEarned),
            mobilePoints = safeAdd(current.mobilePoints, mobileEarned),
            wifiBytesAccounted = wifiTotal,
            mobileBytesAccounted = mobileTotal
        )
    }

    private fun pointsFor(bytes: Long, rate: Long): Long =
        ((bytes / BYTES_PER_GB) * rate) +
            (((bytes % BYTES_PER_GB) * rate) / BYTES_PER_GB)

    private fun safeAdd(a: Long, b: Long): Long =
        if (Long.MAX_VALUE - a < b) Long.MAX_VALUE else a + b

    companion object { const val BYTES_PER_GB = 1_000_000_000L }
}
