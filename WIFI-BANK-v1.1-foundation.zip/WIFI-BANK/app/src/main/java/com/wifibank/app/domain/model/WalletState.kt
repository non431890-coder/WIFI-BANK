package com.wifibank.app.domain.model

data class WalletState(
    val wifiPoints: Long = 0L,
    val mobilePoints: Long = 0L,
    val wifiBytesAccounted: Long = 0L,
    val mobileBytesAccounted: Long = 0L
) {
    val totalPoints: Long get() = wifiPoints + mobilePoints
}
