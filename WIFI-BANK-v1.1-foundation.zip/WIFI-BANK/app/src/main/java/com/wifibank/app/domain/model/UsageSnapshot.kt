package com.wifibank.app.domain.model

data class UsageSnapshot(
    val wifiBytes: Long,
    val mobileBytes: Long,
    val measuredAtEpochMillis: Long
) {
    init {
        require(wifiBytes >= 0L) { "Wi-Fi bytes cannot be negative" }
        require(mobileBytes >= 0L) { "Mobile bytes cannot be negative" }
    }
}
