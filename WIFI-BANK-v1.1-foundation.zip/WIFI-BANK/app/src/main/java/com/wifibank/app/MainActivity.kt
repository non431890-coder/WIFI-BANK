package com.wifibank.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.room.Room
import com.wifibank.app.data.local.WifiBankDatabase
import com.wifibank.app.data.local.WalletEntity
import com.wifibank.app.data.monitoring.AndroidUsageRepository
import com.wifibank.app.data.repository.WalletRepository
import com.wifibank.app.domain.usecase.PointsCalculator
import kotlinx.coroutines.launch

private val Navy = Color(0xFF081321)
private val ElectricBlue = Color(0xFF258BFF)
private val SurfaceBlue = Color(0xFF12243A)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val db = Room.databaseBuilder(applicationContext, WifiBankDatabase::class.java, "wifi-bank.db").build()
        val walletRepo = WalletRepository(db.walletDao())
        val usageRepo = AndroidUsageRepository(applicationContext)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                primary = ElectricBlue,
                background = Navy,
                surface = SurfaceBlue,
                onBackground = Color.White,
                onSurface = Color.White
            )) {
                WifiBankScreen(
                    walletRepo = walletRepo,
                    usageRepo = usageRepo,
                    openUsageSettings = { startActivity(usageRepo.usageAccessSettingsIntent()) }
                )
            }
        }
    }
}

@Composable
private fun WifiBankScreen(
    walletRepo: WalletRepository,
    usageRepo: AndroidUsageRepository,
    openUsageSettings: () -> Unit
) {
    val scope = rememberCoroutineScope()
    var wallet by remember { mutableStateOf(WalletEntity()) }
    var status by remember { mutableStateOf("Loading wallet…") }
    var loading by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        wallet = walletRepo.load()
        status = if (usageRepo.hasUsageAccess()) "Usage access available" else "Usage access required"
    }

    fun refresh() {
        scope.launch {
            loading = true
            try {
                val current = walletRepo.load()
                if (!usageRepo.hasUsageAccess()) {
                    status = "Grant Usage Access to read Android network summaries."
                } else {
                    val now = System.currentTimeMillis()
                    val isInitialBaseline = current.baselineStartAt == 0L
                    val start = if (!isInitialBaseline) current.baselineStartAt else now - 30L * 24 * 60 * 60 * 1000
                    val snapshot = usageRepo.readUsageSince(start, now)
                    val wifiDelta = (snapshot.wifiBytes - current.lastWifiTotalBytes).coerceAtLeast(0L)
                    val mobileDelta = (snapshot.mobileBytes - current.lastMobileTotalBytes).coerceAtLeast(0L)
                    val next = if (current.isCollectionEnabled && !isInitialBaseline) {
                        val calculated = PointsCalculator().applyDelta(
                            walletRepo.toDomain(current), wifiDelta, mobileDelta
                        )
                        current.copy(
                            wifiPoints = calculated.wifiPoints,
                            mobilePoints = calculated.mobilePoints,
                            wifiBytesAccounted = calculated.wifiBytesAccounted,
                            mobileBytesAccounted = calculated.mobileBytesAccounted,
                            lastWifiTotalBytes = snapshot.wifiBytes,
                            lastMobileTotalBytes = snapshot.mobileBytes,
                            baselineStartAt = start
                        )
                    } else current.copy(
                        lastWifiTotalBytes = snapshot.wifiBytes,
                        lastMobileTotalBytes = snapshot.mobileBytes,
                        baselineStartAt = start
                    )
                    walletRepo.save(next)
                    wallet = next
                    status = "Updated from Android network statistics"
                }
            } catch (error: Exception) {
                status = "Could not read usage: ${error.javaClass.simpleName}"
            } finally { loading = false }
        }
    }

    Column(
        modifier = Modifier.fillMaxSize().background(Navy).verticalScroll(rememberScrollState()).padding(22.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("WIFI BANK", color = Color.White, fontSize = 30.sp)
        Text("INTERNET DATA ACCOUNTING", color = ElectricBlue, fontSize = 12.sp)
        Card(colors = CardDefaults.cardColors(containerColor = SurfaceBlue)) {
            Column(Modifier.padding(16.dp)) {
                Text("Virtual points wallet", color = Color.LightGray)
                Text(wallet.totalPoints().toString(), color = Color.White, fontSize = 36.sp)
                Text("Points • not real internet or money", color = Color(0xFFFFD18A), fontSize = 12.sp)
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            UsageCard("Wi-Fi", wallet.wifiPoints, "100 points / GB")
            UsageCard("Mobile", wallet.mobilePoints, "50 points / GB")
        }
        Card(colors = CardDefaults.cardColors(containerColor = SurfaceBlue)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Collection", color = Color.White, fontSize = 18.sp)
                Text(if (wallet.isCollectionEnabled) "Enabled" else "Paused", color = ElectricBlue)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = {
                        scope.launch {
                            wallet = wallet.copy(isCollectionEnabled = !wallet.isCollectionEnabled)
                            walletRepo.save(wallet)
                            status = if (wallet.isCollectionEnabled) "Collection enabled" else "Collection paused"
                        }
                    }) { Text(if (wallet.isCollectionEnabled) "Pause" else "Resume") }
                    OutlinedButton(onClick = ::refresh, enabled = !loading) {
                        Text(if (loading) "Updating…" else "Refresh usage")
                    }
                }
            }
        }
        OutlinedButton(onClick = openUsageSettings, modifier = Modifier.fillMaxWidth()) {
            Text("Open Android Usage Access settings")
        }
        Text(status, color = Color.LightGray, fontSize = 12.sp)
        Text(
            "Measurement depends on Android's available network summaries and device/carrier behavior. " +
                "The app does not inspect browsing content and cannot convert points into carrier data.",
            color = Color.Gray, fontSize = 11.sp
        )
    }
}

@Composable
private fun RowScope.UsageCard(title: String, points: Long, rate: String) {
    Card(modifier = Modifier.weight(1f), colors = CardDefaults.cardColors(containerColor = SurfaceBlue)) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(title, color = Color.LightGray)
            Text(points.toString(), color = Color.White, fontSize = 24.sp)
            Text(rate, color = ElectricBlue, fontSize = 10.sp)
        }
    }
}

private fun WalletEntity.totalPoints(): Long = wifiPoints + mobilePoints
