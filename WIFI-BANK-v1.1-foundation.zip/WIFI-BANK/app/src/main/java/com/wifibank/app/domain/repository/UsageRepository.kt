package com.wifibank.app.domain.repository

import com.wifibank.app.domain.model.UsageSnapshot

interface UsageRepository {
    suspend fun readUsageSince(startEpochMillis: Long, endEpochMillis: Long): UsageSnapshot
    fun hasUsageAccess(): Boolean
}
