package com.wifibank.app.data.repository

import com.wifibank.app.data.local.WalletDao
import com.wifibank.app.data.local.WalletEntity
import com.wifibank.app.domain.model.WalletState

class WalletRepository(private val dao: WalletDao) {
    suspend fun load(): WalletEntity = dao.getWallet() ?: WalletEntity().also { dao.save(it) }
    suspend fun save(entity: WalletEntity) = dao.save(entity)
    fun toDomain(entity: WalletEntity) = WalletState(
        wifiPoints = entity.wifiPoints,
        mobilePoints = entity.mobilePoints,
        wifiBytesAccounted = entity.wifiBytesAccounted,
        mobileBytesAccounted = entity.mobileBytesAccounted
    )
}
