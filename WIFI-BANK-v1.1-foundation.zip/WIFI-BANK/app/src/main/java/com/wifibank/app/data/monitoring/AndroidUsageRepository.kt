package com.wifibank.app.data.monitoring

import android.app.AppOpsManager
import android.app.usage.NetworkStats
import android.app.usage.NetworkStatsManager
import android.content.Context
import android.net.NetworkTemplate
import android.os.Build
import android.os.Process
import android.provider.Settings
import com.wifibank.app.domain.model.UsageSnapshot
import com.wifibank.app.domain.repository.UsageRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Reads device-wide network summaries exposed by Android.
 * Access is controlled by the user's special Usage Access setting.
 * Results vary by Android version, carrier and device manufacturer.
 */
class AndroidUsageRepository(private val context: Context) : UsageRepository {
    override fun hasUsageAccess(): Boolean {
        val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            appOps.unsafeCheckOpNoThrow(
                AppOpsManager.OPSTR_GET_USAGE_STATS,
                Process.myUid(),
                context.packageName
            )
        } else {
            @Suppress("DEPRECATION")
            appOps.checkOpNoThrow(
                AppOpsManager.OPSTR_GET_USAGE_STATS,
                Process.myUid(),
                context.packageName
            )
        }
        return mode == AppOpsManager.MODE_ALLOWED
    }

    override suspend fun readUsageSince(
        startEpochMillis: Long,
        endEpochMillis: Long
    ): UsageSnapshot = withContext(Dispatchers.IO) {
        require(startEpochMillis < endEpochMillis)
        val manager = context.getSystemService(Context.NETWORK_STATS_SERVICE) as NetworkStatsManager
        UsageSnapshot(
            wifiBytes = query(manager, NetworkTemplate.MATCH_WIFI, startEpochMillis, endEpochMillis),
            mobileBytes = query(manager, NetworkTemplate.MATCH_MOBILE, startEpochMillis, endEpochMillis),
            measuredAtEpochMillis = endEpochMillis
        )
    }

    private fun query(
        manager: NetworkStatsManager,
        networkType: Int,
        start: Long,
        end: Long
    ): Long {
        val template = NetworkTemplate.Builder(networkType).build()
        var total = 0L
        val stats: NetworkStats = manager.querySummary(template, start, end)
        try {
            val bucket = NetworkStats.Bucket()
            while (stats.hasNextBucket()) {
                stats.getNextBucket(bucket)
                val rx = bucket.rxBytes.coerceAtLeast(0L)
                val tx = bucket.txBytes.coerceAtLeast(0L)
                total = if (Long.MAX_VALUE - total < rx + tx) Long.MAX_VALUE else total + rx + tx
            }
        } finally {
            stats.close()
        }
        return total
    }

    fun usageAccessSettingsIntent() = android.content.Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)
}
