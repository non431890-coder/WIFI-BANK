# WIFI BANK — Product specification

## Purpose
Track available Android network-usage summaries and award virtual points inside a personal wallet.

## Initial rates
- Wi-Fi: 100 points per 1 GB (decimal GB).
- Mobile data (4G/5G): 50 points per 1 GB (decimal GB).

## Wallet ownership
The initial wallet is local and personal to the Android installation. Cloud synchronization and cross-device identity are not part of this milestone.

## Non-goals
- No interception or inspection of browsing content.
- No claim that points are real internet, money, or redeemable value.
- No carrier integration until a carrier provides a formal, documented integration and authorizes its use.

## MVP acceptance criteria
- App launches on supported Android devices.
- User can open Usage Access settings.
- Wi-Fi and mobile usage are presented separately when Android exposes those summaries.
- Points are calculated independently and persisted locally.
- Pausing collection preserves existing points.
- Domain unit tests pass in CI.
- Debug APK is produced as a CI artifact.
