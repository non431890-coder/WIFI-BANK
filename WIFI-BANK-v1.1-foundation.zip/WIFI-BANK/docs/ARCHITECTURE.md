# Architecture decisions

## Layers

- **Domain:** platform-independent models and deterministic business rules.
- **Data:** Room persistence and Android network-statistics adapter.
- **UI:** Compose screens and user actions.

## Accounting invariants

1. Wi-Fi and mobile usage are tracked independently.
2. Default rates are 100 points per decimal GB for Wi-Fi and 50 points per decimal GB for mobile.
3. Fractional bytes are retained in cumulative accounted-byte totals, so multiple small deltas eventually earn the correct whole-point amount.
4. Negative deltas are rejected by the domain calculator.
5. The first successful read establishes a baseline and does not award historical usage from before setup.
5. Collection pause does not erase the wallet.

## Current limitations to resolve before production

- Robustly handle Android network counter resets and time-window boundaries. The current MVP uses a fixed baseline start time when comparing cumulative summaries.
- Add subscription-aware mobile accounting for dual-SIM devices.
- Add a proper transaction ledger and idempotent collection records.
- Add scheduled background collection with WorkManager and appropriate foreground-service policy only if justified.
- Add localization, accessibility, UI tests, database migrations, and backup/export policy.
- Validate measurements against Android system settings on a device matrix.
