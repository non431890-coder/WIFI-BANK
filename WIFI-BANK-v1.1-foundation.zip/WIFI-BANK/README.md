# WIFI BANK

**Android data-usage accounting and virtual rewards wallet.**

WIFI BANK is being rebuilt as a maintainable Android application using Kotlin, Jetpack Compose, Room, and a Clean Architecture-inspired separation between domain, data, and UI layers.

## Current milestone: 1.1.0 foundation

- Kotlin + Jetpack Compose application shell
- Room persistence for the local wallet
- Domain points calculator with fractional-byte carry-over
- Separate Wi-Fi and mobile usage data source using Android `NetworkStatsManager`
- First-read baseline to avoid awarding pre-setup historical usage
- Usage Access settings entry point
- Unit tests for points calculation
- GitHub Actions build and test workflow

## Important product boundary

Points are **virtual, in-app accounting units**. They are not money and are not carrier data. Converting points into real mobile data requires a formal agreement and a supported API from a participating carrier.

## Network measurement limitations

Android network summaries are system-provided aggregates. Availability and accuracy vary by Android version, manufacturer, carrier, SIM configuration, and permission state. The current implementation is a foundation and must be validated on target devices before being relied on for billing, rewards with monetary value, or carrier settlement.

The first implementation reads cumulative summaries over a time window. A later milestone must harden baseline handling, SIM/subscription selection, counter resets, timezone/window boundaries, and collection scheduling before background collection is considered production-ready.

## Build

Requirements:
- JDK 17
- Android SDK Platform 35
- Android Gradle Plugin 8.7.3 compatible Gradle 8.9

Build and test with Gradle:

```bash
gradle :app:testDebugUnitTest :app:assembleDebug
```

Install the debug APK generated at:

`app/build/outputs/apk/debug/app-debug.apk`

## Repository structure

```text
app/
  src/main/java/com/wifibank/app/
    domain/       # Pure business rules and models
    data/         # Android network data source and Room persistence
    MainActivity.kt
  src/test/       # JVM unit tests
docs/             # Architecture and product decisions
.github/workflows # CI build and tests
```

## Status

This repository is an engineering foundation, not a claim of production readiness. CI and physical-device validation are required before release.
